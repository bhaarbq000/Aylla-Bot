# 🤖 بوت إنستاغرام الذكي — دليل الإعداد الكامل

## ما الذي يفعله هذا البوت؟
يرد تلقائياً على **كل تعليق** في منشوراتك بردود ذكية مخصصة لمتجرك، مدعوم بـ Claude AI.

---

## الخطوة ١ — إعداد Meta Developer App

1. اذهب إلى: **https://developers.facebook.com**
2. اضغط **My Apps** ← **Create App**
3. اختر **Business** ← ادخل اسم التطبيق
4. من القائمة اليسرى: **Add Product** ← اختر **Instagram**
5. في **Instagram Basic Display** أو **Instagram Graph API**:
   - أضف حسابك كـ **Test User**
   - احصل على **Access Token**

### 📋 بيانات تحتاجها:
| البيانات | مكانها |
|---|---|
| `App Secret` | Settings → Basic |
| `Access Token` | Instagram → Generate Token |
| `Page ID` | صفحة الفيسبوك المرتبطة |

---

## الخطوة ٢ — نشر السيرفر على Railway (مجاني)

```bash
# ١. سجل دخول على railway.app
# ٢. New Project → Deploy from GitHub Repo
# ٣. أو استخدم Railway CLI:

npm install -g @railway/cli
railway login
railway init
railway up
```

بعد النشر، ستحصل على رابط مثل:
`https://instagram-bot-production.up.railway.app`

---

## الخطوة ٣ — إعداد ملف البيئة

```bash
# انسخ ملف الإعدادات
cp .env.example .env

# عدّل القيم
nano .env
```

ادخل هذه القيم في `.env`:
```
INSTAGRAM_ACCESS_TOKEN=EAAxxxxxxx   ← من Meta Dashboard
APP_SECRET=xxxxxxxxxx               ← من App Settings
VERIFY_TOKEN=كلمة_سر_تختارها
CLAUDE_API_KEY=sk-ant-xxxxxxx       ← من console.anthropic.com
STORE_NAME=اسم متجرك
STORE_INFO=وصف خدماتك
STORE_EXTRA=معلومات الشحن والدفع
```

---

## الخطوة ٤ — تفعيل Webhook

1. في **Meta Dashboard** → Instagram → **Webhooks**
2. اضغط **Subscribe to this object**
3. ادخل:
   - **Callback URL**: `https://YOUR_DOMAIN/webhook`
   - **Verify Token**: نفس الكلمة في `.env` (مثال: `aylla_secret_2026`)
4. اضغط **Verify and Save**
5. من **Subscription Fields** فعّل: ✅ **comments**

---

## الخطوة ٥ — تشغيل السيرفر

```bash
# تثبيت المكتبات
npm install

# تشغيل مباشر
npm start

# أو تشغيل مع Auto-Restart
npm run dev
```

---

## ✅ اختبار البوت

```bash
# تحقق أن السيرفر يعمل
curl https://YOUR_DOMAIN/

# اختبار Webhook يدوياً
curl -X GET "https://YOUR_DOMAIN/webhook?hub.mode=subscribe&hub.verify_token=aylla_secret_2026&hub.challenge=TEST123"
# المفروض يرجع: TEST123
```

الآن اذهب لأحد منشوراتك وعلق أي شيء — سيرد البوت خلال ثوانٍ! 🎉

---

## 🛠️ حل المشاكل الشائعة

| المشكلة | الحل |
|---|---|
| `403 Forbidden` في Webhook | تأكد VERIFY_TOKEN متطابق |
| لا يرد على التعليقات | تأكد اشتراك `comments` مفعّل |
| خطأ في Claude API | تحقق من CLAUDE_API_KEY |
| السيرفر لا يبدأ | تأكد تثبيت `npm install` |

---

## 🔒 ملاحظات أمان

- لا تشارك ملف `.env` مع أحد
- أضف `.env` في ملف `.gitignore`
- جدد Access Token قبل انتهائه (كل 60 يوم)

---

## 📞 للمساعدة
راجع الكود أو تواصل مع المطور.
