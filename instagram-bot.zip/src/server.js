const express = require("express");
const axios = require("axios");
const crypto = require("crypto");
require("dotenv").config();

const app = express();

// ✅ Parse raw body for signature verification
app.use(express.json({ verify: (req, res, buf) => { req.rawBody = buf; } }));

const {
  VERIFY_TOKEN,
  INSTAGRAM_ACCESS_TOKEN,
  CLAUDE_API_KEY,
  STORE_NAME,
  STORE_INFO,
  STORE_EXTRA,
  APP_SECRET,
  PORT = 3000,
} = process.env;

// ─────────────────────────────────────────────
// 🔐 Verify Instagram Signature
// ─────────────────────────────────────────────
function verifySignature(req) {
  const sig = req.headers["x-hub-signature-256"];
  if (!sig || !APP_SECRET) return true; // skip in dev
  const hmac = crypto.createHmac("sha256", APP_SECRET);
  hmac.update(req.rawBody);
  const expected = "sha256=" + hmac.digest("hex");
  return sig === expected;
}

// ─────────────────────────────────────────────
// 🤖 Generate AI Reply via Claude
// ─────────────────────────────────────────────
async function generateReply(commentText) {
  const systemPrompt = `أنت مساعد ذكي يرد على تعليقات إنستاغرام لمتجر "${STORE_NAME}".
طبيعة العمل: ${STORE_INFO}
أسلوبك: ودود، مختصر جداً (جملة أو جملتين فقط)، باللهجة الخليجية، استخدم إيموجي مناسب.
ردك طبيعي كأنك صاحب البراند ترد على زبون.
معلومات: ${STORE_EXTRA}`;

  const response = await axios.post(
    "https://api.anthropic.com/v1/messages",
    {
      model: "claude-sonnet-4-20250514",
      max_tokens: 200,
      system: systemPrompt,
      messages: [
        {
          role: "user",
          content: `تعليق زبون: "${commentText}"\nاكتب رد قصير ومناسب.`,
        },
      ],
    },
    {
      headers: {
        "x-api-key": CLAUDE_API_KEY,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json",
      },
    }
  );
  return response.data.content[0].text;
}

// ─────────────────────────────────────────────
// 📤 Post Reply to Instagram Comment
// ─────────────────────────────────────────────
async function postReply(commentId, replyText) {
  await axios.post(
    `https://graph.instagram.com/v21.0/${commentId}/replies`,
    { message: replyText },
    { params: { access_token: INSTAGRAM_ACCESS_TOKEN } }
  );
  console.log(`✅ رد على التعليق ${commentId}: ${replyText}`);
}

// ─────────────────────────────────────────────
// 🔗 Webhook Verification (GET)
// ─────────────────────────────────────────────
app.get("/webhook", (req, res) => {
  const mode = req.query["hub.mode"];
  const token = req.query["hub.verify_token"];
  const challenge = req.query["hub.challenge"];

  if (mode === "subscribe" && token === VERIFY_TOKEN) {
    console.log("✅ Webhook تم التحقق بنجاح!");
    return res.status(200).send(challenge);
  }
  console.log("❌ فشل التحقق من Webhook");
  res.sendStatus(403);
});

// ─────────────────────────────────────────────
// 📥 Receive Events (POST)
// ─────────────────────────────────────────────
app.post("/webhook", async (req, res) => {
  if (!verifySignature(req)) {
    console.log("❌ توقيع غير صحيح");
    return res.sendStatus(403);
  }

  const body = req.body;
  res.sendStatus(200); // رد فوري على Meta

  if (body.object !== "instagram") return;

  for (const entry of body.entry || []) {
    for (const change of entry.changes || []) {
      if (change.field !== "comments") continue;

      const { id: commentId, text, from } = change.value;
      const username = from?.username || "مستخدم";

      console.log(`💬 تعليق جديد من @${username}: ${text}`);

      // تجاهل التعليقات الفارغة أو القصيرة جداً
      if (!text || text.trim().length < 2) continue;

      try {
        const reply = await generateReply(text);
        await postReply(commentId, reply);
      } catch (err) {
        console.error("❌ خطأ في الرد:", err.response?.data || err.message);
      }
    }
  }
});

// ─────────────────────────────────────────────
// 🏥 Health Check
// ─────────────────────────────────────────────
app.get("/", (req, res) => {
  res.json({
    status: "✅ السيرفر يعمل",
    store: STORE_NAME,
    timestamp: new Date().toISOString(),
  });
});

app.listen(PORT, () => {
  console.log(`🚀 السيرفر يعمل على البورت ${PORT}`);
  console.log(`📌 Webhook URL: https://YOUR_DOMAIN/webhook`);
});
